Open index.html in a browser, or upload the folder to GitHub Pages / Vercel. This version uses exact YouTube watch URLs for every card.
