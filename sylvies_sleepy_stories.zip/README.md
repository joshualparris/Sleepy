# Sylvie's Sleepy Stories

Single-file bedtime story picker.

## Open locally
Open `index.html` in any browser.

## Deploy
- GitHub Pages: upload `index.html` to a repo and enable Pages
- Vercel: import repo or drag/drop the file

## Notes
This version is reliability-first:
- hardcoded bedtime library
- favourites and recent plays saved in localStorage
- Sylvie Mode for simple kid-friendly browsing
- cards open YouTube search results for the exact title + channel

Later, exact YouTube watch links and thumbnails can be added per story if you want.
